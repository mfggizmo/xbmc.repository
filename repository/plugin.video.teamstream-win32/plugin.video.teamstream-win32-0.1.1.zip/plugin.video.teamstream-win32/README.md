Teamstream.to Live-TV Addon for XBMC
==============================

Steps to be done before using the teamstream addon:
--------------------------------------------------------------------------------
* get an account at www.teamstream.to
* buy elite access
* download patched librtmp.dll (KSV) from https://github.com/K-S-V/Scripts/downloads
* navigate to %XBMC-ROOT%\system\players\dvdplayer and replace librtmp.dll
* enter your login and password in the addon settings
* enjoy live television!

Credit:
--------------------------------------------------------------------------------
Author of Teleboy Plugin - this plugin is based on it
