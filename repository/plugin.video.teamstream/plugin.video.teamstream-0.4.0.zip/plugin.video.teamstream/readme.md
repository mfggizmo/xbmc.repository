Teamstream Live-TV (Sky Stream) Addon für XBMC
====================================

Kurzanleitung für die Benutzung des Teamstream.to XBMC plugin:
* Besorge dir einen invite für www.teamstream.to
* Kaufe dir einen Elite Zugang
* Folge den Installationsanweisungen im Wiki: https://github.com/siriuzwhite/plugin.video.teamstream/wiki
* Gib deinen Benutzernamen und dein Passwort in den Plugin Einstellungen ein
* Viel Spaß beim Sky schauen ;)

Credits:
--------------------------------------------------------------------------------------
- an Skandi (http://redmine.mindmade.org/projects/xbmc-teleboy)
- an die Crew von teamstream.to für ihren einzigartigen Service
