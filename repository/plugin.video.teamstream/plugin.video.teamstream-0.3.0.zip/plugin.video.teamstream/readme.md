Teamstream.to Live-TV Addon für XBMC
====================================

Kurzanleitung für die Benutzung des teamstream.to XBMC plugin:
* Besorge dir einen invite für www.teamstream.to
* Kaufe dir einen Elite Zugang
* Folge den Installationsanweisungen im Wiki: https://github.com/siriuzwhite/plugin.video.teamstream/wiki
* Gib deinen Benutzernamen und dein Passwort in den Plugin Einstellungen ein.
* Viel Spaß beim Sky schauen ;)

Credit:
--------------------------------------------------------------------------------------
- an den Autor vom Teleboy.ch Plugin, dieses Plugin basiert zu großen Teilen darauf
- an die Crew von teamstream.to für ihren einzigartigen Service
